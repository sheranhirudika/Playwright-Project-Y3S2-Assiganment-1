import { test, expect, Page } from "@playwright/test";

// Configuration
const CONFIG = {
  url: "https://www.swifttranslator.com/",
  timeouts: {
    pageLoad: 2000,
    afterClear: 1000,
    translation: 3000,
    betweenTests: 2000,
  },
  selectors: {
    inputField: "Input Your Singlish Text Here.",
    outputContainer:
      "div.w-full.h-80.p-3.rounded-lg.ring-1.ring-slate-300.whitespace-pre-wrap",
  },
};

// Types
interface TestCase {
  tcId: string;
  name: string;
  input: string;
  expected: string;
  category: string;
  grammar: string;
  length: string;
}

interface UiTestCase {
  tcId: string;
  name: string;
  input: string;
  partialInput: string;
  expectedFull: string;
  category: string;
  grammar: string;
  length: string;
}

// Test Data
const TEST_DATA: {
  positive: TestCase[];
  negative: TestCase[];
  ui: UiTestCase;
} = {
  positive: [
    {
      tcId: "Pos_Fun_1",
      name: "Simple  tense statement",
      input: "dhaen udhee velaa",
      expected: "දැන් උදේ වෙලා",
      category: "Daily language usage",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_2",
      name: "Compound sentence",
      input: "man gedhera avaa, kaeema laeesthi karalaa naenee",
      expected: "මන් ගෙදෙර අවා, කෑම ලෑස්ති කරලා නැනේ",
      category: "Daily language usage",
      grammar: "Compound sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_3",
      name: "Interrogative statemant",
      input: "oyaa hodhin innavadha?",
      expected: "ඔයා හොදින් ඉන්නවද?",
      category: "Daily language usage",
      grammar: "Interrogative sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_4",
      name: "Request statement",
      input: "mata podi udhavuvak karanna puLuvandha?",
      expected: "මට පොඩි උදවුවක් කරන්න පුළුවන්ද?",
      category: "Daily usage language",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_5",
      name: "Response statement",
      input: "anivaarYenma puLuvan",
      expected: "අනිවාර්යෙන්ම පුළුවන්",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_6",
      name: "Polite statement",
      input: "ee gaena kaNagaatuyi",
      expected: "ඒ ගැන කණගාටුයි",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_7",
      name: "Informal statement",
      input: "karanna dheyak naee bQQ",
      expected: "කරන්න දෙයක් නෑ බං",
      category: "Dialy language",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_8",
      name: "Frequent statement",
      input: "mata passee kathaa karanna puLuvannee",
      expected: "මට පස්සේ කතා කරන්න පුළුවන්නේ",
      category: "daily usage",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_9",
      name: "Properly Spaced statement",
      input: "yanna enna yaaLuvee",
      expected: "යන්න එන්න යාළුවේ",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_10",
      name: "Improperly spaced statement",
      input: "yannaenna yaluwe",
      expected: "යන්නඑන්න යාළුවේ",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_11",
      name: "statement with currency",
      input: "mata Rs. 500 k‌ dhenna puLuvan",
      expected: "මට Rs. 500 ක්‌ දෙන්න පුළුවන්",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_12",
      name: "statement with english words",
      input: "good morning sahoodharayaa",
      expected: "good morning සහෝදරයා",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_13",
      name: "statement with a name",
      input: "kohomadha dhavasa sumanasiri?",
      expected: "කොහොමද දවස සුමනසිරි?",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_14",
      name: "statement with english brand name",
      input: "oyaagee dhurakaThanaya Microsoft dha?",
      expected: "ඔයාගේ දුරකථනය Microsoft ද?",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_15",
      name: "Past tence statement",
      input: "mama gedhara aavaa",
      expected: "මම ගෙදර ආවා",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_16",
      name: "Present tence statement",
      input: "api sindhu kiyanavaa",
      expected: "අපි සින්දු කියනවා",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_17",
      name: "Future tence statement",
      input: "eyaa heta enavaa",
      expected: "එයා හෙට එනවා",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_18",
      name: "statement with a slang",
      input: "adoo machQQ vaedee amaaruyi nee",
      expected: "අඩෝ මචං වැඩේ අමාරුයි නේ",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_19",
      name: "statement with measurement units",
      input: "oyaata thava 100km enna thiyenavaa",
      expected: "ඔයාට තව 100km එන්න තියෙනවා",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_20",
      name: "statement with date",
      input: "adha dhinee 30/01/2026",
      expected: "අද දිනේ 30/01/2026",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_21",
      name: "statement with english abbrevations",
      input: "mata SMS ekak evanna",
      expected: "මට SMS එකක් එවන්න",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_22",
      name: "Statement with ultiple spaces",
      input: "adha  magee oLuva ridhenavaa",
      expected: "අද  මගේ ඔළුව රිදෙනවා",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Pos_Fun_23",
      name: "Request statement",
      input: "mata podi udhavvak karanna puLuvandha?",
      expected: "මට පොඩි උදව්වක් කරන්න පුළුවන්ද?",
      category: "Punctuation / numbers",
      grammar: "Simple sentence",
      length: "S",
    },

    {
      tcId: "Pos_Fun_24",
      name: "Medium length conversation",
      input:
        "heta mata vaeda godak thiyanavaa oyaata poddak maaLunta kanna dhaanna puLuvandha?",
      expected:
        "හෙට මට වැඩ ගොඩක් තියනවා ඔයාට පොඩ්ඩක් මාළුන්ට කන්න දාන්න පුළුවන්ද?",
      category: "Daily language usage",
      grammar: "Compound sentence",
      length: "M",
    },
  ],

  negative: [
    {
      tcId: "Neg_Fun_1",
      name: "Missing space between words",
      input: "mama kemata pan genawa",
      expected: "මං කෑමට පාන් ගෙනාවා",
      category: "Daily usage language",
      grammar: "Simple sentence",
      length: "S",
    },
    {
      tcId: "Neg_Fun_2",
      name: "Joined compound words",
      input: "pissu da appa",
      expected: "පිස්සුද අප්පා",
      category: "Slang /informal language",
      grammar: "Informal sentense",
      length: "S",
    },
    {
      tcId: "Neg_Fun_3",
      name: "Joined compound words",
      input: "ada mata vayasa 24i",
      expected: "අද මට වයස 24යි",
      category: "Daily usage language",
      grammar: "present tense",
      length: "S",
    },
    {
      tcId: "Neg_Fun_4",
      name: "Joined compound words",
      input: "raa mata ninda giye na",
      expected: "රෑ මට නින්ද ගියේ නෑ",
      category: "daiy usage language",
      grammar: "past tense",
      length: "S",
    },
    {
      tcId: "Neg_Fun_5",
      name: "Joined compound words",
      input: "kamata monawa hari denna ko?",
      expected: "කෑමට මොනවා හරි දෙන්නකෝ?",
      category: "Typographical error handling",
      grammar: "simple sentense",
      length: "S",
    },
    {
      tcId: "Neg_Fun_6",
      name: "Joined compound words",
      input: "mama ENGLISH teacher kenek",
      expected: "මම ENGLISH teacher කෙනෙක්",
      category: "mixed english and singlish",
      grammar: "Present tense",
      length: "S",
    },
    {
      tcId: "Neg_Fun_7",
      name: "Joined compound words",
      input: "ada janavari 29",
      expected: "අද ජනවාරි 29",
      category: "daily language usage",
      grammar: "Present tense",
      length: "S",
    },
    {
      tcId: "Neg_Fun_8",
      name: "Joined compound words",
      input: "sudda ape rata haduwa",
      expected: "සුද්දා අපේ රට හැදුවා",
      category: "daily usage language",
      grammar: "simple sentence",
      length: "S",
    },
    {
      tcId: "Neg_Fun_9",
      name: "-",
      input: "oyamagesada ",
      expected: "ඔයා මගේ සඳ",
      category: "Formatting",
      grammar: "simple sentense",
      length: "S",
    },
    {
      tcId: "Neg_Fun_10",
      name: "-",
      input: "passe thamai kiyanna wenne",
      expected: "පස්සේ තමයි කියන්න වෙන්නේ",
      category: "Daily speakinh langauge",
      grammar: "Simple sentense",
      length: "S",
    },
  ],

  ui: {
    tcId: "Pos_UI_001",
    name: "Real-time translation updates as typing",
    input: "mama kaeema kannavaa",
    partialInput: "mama kae",
    expectedFull: "මම කෑම කන්නවා",
    category: "Usability flow",
    grammar: "Present tense",
    length: "S",
  },
};

// Helper Class
class TranslatorPage {
  private page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async navigateToSite(): Promise<void> {
    await this.page.goto(CONFIG.url);
    await this.page.waitForLoadState("networkidle");
    await this.page.waitForTimeout(CONFIG.timeouts.pageLoad);
  }

  async getInputField() {
    return this.page.getByRole("textbox", {
      name: CONFIG.selectors.inputField,
    });
  }

  async getOutputField() {
    return this.page
      .locator(CONFIG.selectors.outputContainer)
      .filter({ hasNot: this.page.locator("textarea") })
      .first();
  }

  async clearAndWait(): Promise<void> {
    const input = await this.getInputField();
    await input.clear();
    await this.page.waitForTimeout(CONFIG.timeouts.afterClear);
  }

  async typeInput(text: string): Promise<void> {
    const input = await this.getInputField();
    await input.fill(text);
  }

  async waitForOutput(): Promise<void> {
    await this.page.waitForFunction(
      () => {
        const elements = Array.from(
          document.querySelectorAll(
            ".w-full.h-80.p-3.rounded-lg.ring-1.ring-slate-300.whitespace-pre-wrap",
          ),
        );
        const output = elements.find((el) => {
          const isInputField =
            el.tagName === "TEXTAREA" || el.getAttribute("role") === "textbox";
          return (
            !isInputField && el.textContent && el.textContent.trim().length > 0
          );
        });
        return output !== undefined;
      },
      { timeout: 10000 },
    );
    await this.page.waitForTimeout(CONFIG.timeouts.translation);
  }

  async getOutputText(): Promise<string> {
    const output = await this.getOutputField();
    const text = await output.textContent();
    return text?.trim() ?? "";
  }

  async performTranslation(inputText: string): Promise<string> {
    await this.clearAndWait();
    await this.typeInput(inputText);
    await this.waitForOutput();
    return await this.getOutputText();
  }
}

// Test Suite
test.describe("SwiftTranslator - Singlish to Sinhala Conversion Tests", () => {
  let translator: TranslatorPage;

  test.beforeEach(async ({ page }) => {
    translator = new TranslatorPage(page);
    await translator.navigateToSite();
  });

  // Positive Functional Tests
  test.describe("Positive Functional Tests", () => {
    for (const testCase of TEST_DATA.positive) {
      test(`${testCase.tcId} - ${testCase.name}`, async () => {
        const actualOutput = await translator.performTranslation(
          testCase.input,
        );
        expect(actualOutput).toBe(testCase.expected);
        await translator.page.waitForTimeout(CONFIG.timeouts.betweenTests);
      });
    }
  });

  // Negative Functional Tests
  test.describe("Negative Functional Tests", () => {
    for (const testCase of TEST_DATA.negative) {
      test(`${testCase.tcId} - ${testCase.name}`, async () => {
        const actualOutput = await translator.performTranslation(
          testCase.input,
        );
        expect(actualOutput).toBe(testCase.expected);
        await translator.page.waitForTimeout(CONFIG.timeouts.betweenTests);
      });
    }
  });

  // UI Test
  test.describe("UI Functionality Tests", () => {
    test(`${TEST_DATA.ui.tcId} - ${TEST_DATA.ui.name}`, async ({ page }) => {
      const translator = new TranslatorPage(page);
      const input = await translator.getInputField();
      const output = await translator.getOutputField();

      await translator.clearAndWait();

      // Type partial input
      await input.pressSequentially(TEST_DATA.ui.partialInput, { delay: 150 });

      // Wait for partial output
      await page.waitForTimeout(1500);

      // Verify partial translation appears
      let outputText = await output.textContent();
      expect(outputText?.trim().length).toBeGreaterThan(0);

      // Complete typing
      await input.pressSequentially(
        TEST_DATA.ui.input.substring(TEST_DATA.ui.partialInput.length),
        { delay: 150 },
      );

      // Wait for full translation
      await translator.waitForOutput();

      // Verify full translation
      outputText = await translator.getOutputText();
      expect(outputText).toBe(TEST_DATA.ui.expectedFull);

      await page.waitForTimeout(CONFIG.timeouts.betweenTests);
    });
  });
});
