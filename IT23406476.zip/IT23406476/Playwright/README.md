SinglishTest.spec.ts contains the code for testingthe web app
Prequasites - Install playwright in your deice command using command 'npx playwright install'

Step 1 - Download this foldder on your local device
Step 2 - open the folder via VS code
Step 3 - Open terminal
Step 4 - Enter 'npx playwright test --headed' and press enter

That's it You'll see Playwright taking care of the rest
Thank you
